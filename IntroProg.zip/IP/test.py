def piglatin (c) :
    c = c + " "
    p = ""
    cf = ""
    #Cortamos la cadena en palabras y las comvertimos a PigLatin
    #luego las volvemos a unir en la nueva cadena 'cf'
    for i in range (len(c)) :
        if c[i] == " ":
            p = p[1:]+p[0]+'AY'       
            cf = cf + " " + p
            p = ""
        else :
            p = p + c[i]
    return (cf)
         
 
c = input("Ingrese cadena:")
print (piglatin(c))
input
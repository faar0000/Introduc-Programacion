def copiarLista(XS):
	if len(XS)==1:
		return YS+XS
	else:
		XS=XS[::-1]
		return YS+XS
	
XS=[2,4,6,7,8]
YS=[1,1,1,1]
print("La nueva lista es:", copiarLista(XS))

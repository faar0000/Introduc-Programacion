def ingresar(L,n):
	for i in range(n):
		L.append(int(input("Valor:")))
def mostrar(L,n):
	for i in range(n):
		print(L[i],end=" ")

L=[]
n=int(input("Cantidad de elementos:"))
ingresar(L,n)
print("El contenido de la lista es:")
mostrar(L,n)


#Practica 5 n°1
	

def mayorLista(XS):	
	b=0
	for i in range(len(XS)):	
		if XS[i]>b:
			b=XS[i]
	return b
XS=[2,-7,3,8,10]
print(mayorLista(XS))

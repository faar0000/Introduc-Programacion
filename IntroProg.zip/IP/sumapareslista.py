def sumaparesLista(XS):
	if len(XS)==1:
		return XS
	else:	
		c=0
		
		for i in range(len(XS)):	
			if i%2==0:
				c=c+XS[i]	
				
		return c
	
XS=[2,4,6,7,8]
print("La suma es:", sumaparesLista(XS))

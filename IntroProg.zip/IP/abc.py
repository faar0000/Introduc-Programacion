def inverteLista(XS):
	if len(XS)==1:
		return XS
	else:
		return (XS[::-1])
XS=[2,4,6,7,8]
print("La nueva lista es:", inverteLista(XS))

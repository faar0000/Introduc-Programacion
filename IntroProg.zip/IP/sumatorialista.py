def sumatoriaLista(n):	
	a=0
	b=0
	for i in range(1,n+1):
		a=a*10+i
		b=b+a
	return b
n=int(input("Inserte numero:"))
print("La sumatoria es:",sumatoriaLista(n))
#practica 2

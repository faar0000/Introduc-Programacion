def listaPositivos(XS):
	c=0	
	for i in range(len(XS)):	
		if XS[i]>=0:
			c+=1
	return c
def listaNegativos(XS):
	c=0
	for i in range(len(XS)):
		if XS[i]<0:
			c+=1
	return c
XS=[2,-7,3,8,10]
print("Hay",listaPositivos(XS),"positivos y ",listaNegativos(XS))

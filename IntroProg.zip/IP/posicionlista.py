def listaNueva(XS,n):	
	YS=XS.pop(n)
	print YS		
XS=[2,-7,3,8,2,10,3,2,2,3]
n=int(input("Posicion:")
listaNueva(XS,n)
print ("La nueva lista es:",listaNueva(XS,n))

def multiplodeTres(XS):
	c=0
	for i in range (len(XS)):
		if XS[i]%3==0:
			c+=1
	return c
XS=[0,3,9,5,12]
print(multiplodeTres(XS),"son multiplos de 3")

#rayuela.txt es un archivo donde las lineas se encuentran intecalados crear dos nuevos archivos para guardar la informacion correcta
infile=open("rayuela.txt","r")
outfile=open("carta.txt","w")
outfile2=open("solicitud.txt","w")
linea=infile.readline()
i=1
while linea!="":
	if i%2==0:
		outfile2.write(linea)
	else:
		outfile.write(linea)
	i+=1
	linea=infile.readline()
outfile.close()
outfile2.close()

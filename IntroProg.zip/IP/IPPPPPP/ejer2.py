#leer el contenido del archivo
infile=open("escritura.txt","r")
contenido=infile.read()
print(contenido)
infile.close()

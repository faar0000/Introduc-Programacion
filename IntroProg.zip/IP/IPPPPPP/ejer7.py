# hallar la longitud de cada linea de un archivo e indicar la mayor longitud
infile=open("rayuela.txt","r")
linea=infile.readline()
i=1
x=0
while linea!="":
	print("Longitud de linea",i,":",len(linea))	
	i+=1	
	if (len(linea))>x:
		x=(len(linea))
	linea=infile.readline()
print("Mayor longitud:",x)
infile.close()



#copiar el contenido de un archivoa otro , reemplazando los espacios en blacno por un "*"
infile=open("escritura.txt","r")
outfile=open("F2.txt","w")
contenido=infile.read()
for i in contenido:
	if  i==" ":
		outfile.write("*")
	else:
		outfile.write(i)
outfile.close()
infile.close()




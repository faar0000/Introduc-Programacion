
def crearMatriz(M,f,c):
	for i in range(f):
		M.append([0]*c)
	for i in range(f):
		for j in range(c):
			M[i][j]=int(input("Valor:"))
def mostrarMatriz(M):
	for i in M:
		print (i)

def identidad(M):    
        for i in range (len(M)):
            for j in range (len(M[i])):
                if i!=j:
                    if M[i][j]==0:
                        continue
                elif i==j:
                    if M[i][j]==1:
                        continue
                    else:
                        return ("No es Identidad")
        return ("Es Identidad")
def transpuesta(M):
	ys=[]
	for i in range(len(M[1])):
		ys.append([0]*len(M))    
	for i in range (len(M[1])):
		for j in range (len(M)):
			ys[i][j]=M[j][i]
	print ()
	mostrarMatriz(ys)

def intercambiar(M):
    x=int(input("Fila X "))
    y=int(input("Fila Y "))
    a=M[x-1]
    M[x-1]=M[y-1]
    M[y-1]=a
    return M			
	
M=[]
f=int(input("N° de filas:"))
c=int(input("N° de columnas:"))
crearMatriz(M,f,c)
mostrarMatriz(M)
if f==c:
    print(identidad(M))
else:
    print("Matrices no son cuadradas no se puede efectuar:")
transpuesta(M)
print(intercambiar(M))

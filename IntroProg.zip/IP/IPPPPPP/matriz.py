def crearMatriz(M,f,c):
	for i in range(f):
		M.append([0]*c)
	for i in range(f):
		for j in range(c):
			M[i][j]=int(input("Valor:"))
def mostrarMatriz(M):
	for i in M:
		print (i)
def sumarFilas(M):
    for i in range(len(M)):
        print("Suma de fila N°"+str(i+1)+":",sum(M[i]))
def sumadematriz(M):
    s=0
    for i in M:
        s+= sum(i)
    return s
def sumadiagonal(M):
	s=0
    for i in range(len(M)):
        s+=M[i][i]
    return s
def sumadiagonalsec(M):
    s=0
    for i in range(len(M)):
        s+=M[i][len(M-1-i)]
    return s
def contornoMatriz(M):
    for i in range(len(M)):
        if i==0 or i==len(M)-1:
            for j in range(len(M)):
                print(M[i][j],end=" ")
        else:
            print(M[i][0]," "*len(M)-1,M[i][len(M)-1])
def formaNmatriz(M):
    for i in range(len(M)):
        for j in range(len(M)):
            if j==i or j==0 or j==len(M)-1:
                print(M[i][j],end=" ")
        print()



M=[]
f=int(input("N° de filas:"))
c=int(input("N° de columnas:"))
crearMatriz(M,f,c)
mostrarMatriz(M)
sumarFilas(M)
print("Suma de matriz:",sumadematriz(M))
if f==c:
    print("Suma de diagonal:",sumadiagonal(M))
    print("Suma de diagonal secundaria:",sumadiagonalsec(M))
    formaNmatriz(M)   
else:
    print("Matrices no son cuadradas no se puede efectuar diagonales:")



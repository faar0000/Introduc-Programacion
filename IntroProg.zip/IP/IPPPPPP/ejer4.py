#lee el contido del archivo linea por linea
infile=open("escritura.txt","r")
linea=infile.readline()
while linea!="":
	print(linea,end="")
	linea=infile.readline()
infile.close()

#seunda forma
#for i in infile:
#	print(linea)
#infile.close()

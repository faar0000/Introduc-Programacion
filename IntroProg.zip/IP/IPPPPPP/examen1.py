#Verificar si los valores que representan la suma de cada filas de una matriz se encuentran ordenadas:

def crearMatriz(M,f,c):
	for i in range(f):
		M.append([0]*c)
	for i in range(f):
		for j in range(c):
			M[i][j]=int(input("Valor:"))
def mostrarMatriz(M):
	for i in M:
		print (i)
def sumarFilas(M):
	c=0
	for i in range(len(M)):
		print("Suma de fila N°"+str(i+1)+":",sum(M[i]))
		if sum(M[i])>= c:
			c+=sum(M[i])
			print("Esta ordenado")
		else:
			print("No esta ordenado")
M=[]
f=int(input("N° de filas:"))
c=int(input("N° de columnas:"))
crearMatriz(M,f,c)
mostrarMatriz(M)
sumarFilas(M)

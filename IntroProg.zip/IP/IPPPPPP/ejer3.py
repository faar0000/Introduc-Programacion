#leer el cntenido del archivo y mostrar los caracteres separados por un guion
infile=open("escritura.txt","w")
contenido=infile.read()
for i incontenido:
	print(i,end="-")

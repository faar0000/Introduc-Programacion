#Copiar el contenido de un archivo a otro ,invirtiendo el contenido
infile=open("file1.txt","r")
outfile=open("file2.txt","w")
contenido=infile.read()
outfile.write(contenido[::-1])
outfile.close()
infile.close()

f=open("escritura.txt","r")
c=f.read().splitlines()
d=0
for i in c:
	p=len(i.split(" "))
	d=d+p
print(d)

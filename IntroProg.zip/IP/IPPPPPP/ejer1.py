#crea un archivo txt y le escribe W= para escribir o sobreescribir, a= para append añade al final del texto siempre añade
outfile=open("escritura.txt","w")
outfile.write("Hola\n")
outfile.write("como estas!")
outfile.close()

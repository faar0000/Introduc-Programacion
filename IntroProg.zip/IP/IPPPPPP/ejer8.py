#indicar la cantidad de caracteres , lineas y palabras que hay en un archivo
infile=open("rayuela.txt","r")
linea=infile.readline()
contenido=infile.read()
x=0
c=0
y=0
for i in linea:	
	x+=1	
print("Cantidas de lineas:",x-1)
for i in contenido:
	if  i!=" " or i!="":
		c+=1
print("Caracteres:",c)

t=infile.read().splitlines()
d=0
for i in t:
	p=len(i.split(" "))
	d=d+p
print("Numero de palabras es :",d)

infile.close()

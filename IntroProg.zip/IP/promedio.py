def promedio(XS):
	c=1	
	for i in (XS):	
		c=c*i
	return c
XS=[1,2,3,4]
print("El promedio es:",promedio(XS))
	

#ingresar n numero enteros a una lista y hallar el promedio
def ingresar(L,n):
	for i in range(n):
		L.append(int(input("Valor:")))
def media(L,n):
	b=0	
	c=0
	for i in L:
		c+=i
		b+=1
	return c/b
def varianza(L,n):
	import math
	b=0	
	c=0
	y=0
	m=0
	x=0
	for i in L:
		c+=i
		b+=1
	x=c/b
	for i in range (len(L)):
		c=L[i]-x
		y=y+c
	m=math.sqrt(y/b)
	return "y la varianza es:",y/b," y la desviacion es:",m

L=[]
n=int(input("Cantidad de elementos:"))
ingresar(L,n)
print("La media de la lista es:",media(L,n),varianza(L,n))

def elementoRepetido(XS):	
	c=0
	for i in range(len(XS)):	
		c=XS.count(XS[i])
	return 	c	
XS=[2,-7,3,8,2,10,3,2,2,3]
print("Se repite",elementoRepetido(XS),"veces")

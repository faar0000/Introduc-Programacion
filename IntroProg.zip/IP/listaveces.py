def busquedalistaSuma(XS,x):	
	c=0
	for i in range(len(XS)):	
		if XS[i]==x:
			c+=1
	return c
XS=[2,-7,3,8,2,2,2,10]
x=2
print("Se repite",busquedalistaSuma(XS,x),"veces")

def ingresar(XS,n):
	for i in range(n):
		XS.append(int(input("Valor:")))
def ingresar(YS,n):
	for i in range(n):
		YS.append(int(input("Valor:")))

def productoLista(XS,YS):	
	b=0
	for i in range(len(xs)):
		XS[i]=xs[i]*YS[i]
	return XS
def sumLista(XS,YS):	
	return XS+YS

XS=[]
YS=[]
n=int(input("Cantidad de elementos para lista 1:"))
ingresar(XS,n)
n=int(input("Cantidad de elementos para lista 2:"))
ingresar(YS,n)
print("El producto es",productoLista(XS,n)," Y la suma es ",sumaLista(XS,n))

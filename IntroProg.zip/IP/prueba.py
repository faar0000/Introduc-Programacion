def pruebaLista(XS):
	c=0
	for i in range (len(XS)):
		c=c+XS[i]
	return c,"lalalalal"
XS=[1,2,3,4]
print("el promedio es",pruebaLista(XS))

def listaBusqueda(XS,x):	
	for i in range(len(XS)):	
		if XS[i]==x:
			return True
	return False

XS=[2,-7,3,8,10]
x=3
print(listaBusqueda(XS,x))

def separar(xs):
	ab = list(xs) # separamos la entrada de texto en un arreglo de caracteres
	print (ab) # para verificar la generación de la lista

	# el siguiente paso es encontrar los valores indice de " " (espacios en blanco)
	# antes de cada espacio en blanco debemos agregar la cadena "ay" o 
	# lo que es lo mismo una lista ['a','y'], además en cada palabra, es decir en el rango de 
	# valores indice entre los espacios de debe quitar la primera letra y colocarla al final de
	# la palabra

	for i in range(len(ab)):
		if ab[i] == " ":
			ab.insert("ay",i)
	print (ab)

xs = "hola Mundo !"
separar(xs)
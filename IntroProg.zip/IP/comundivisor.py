def esComunDivisor(a,b,c):
	if b%a==0 and c%a==0:	
		return True
	return False
a=int(input("Inserte numero:"))
b=int(input("Inserte numero:"))
c=int(input("Inserte numero:"))
if esComunDivisor(a,b,c):
	print(a,"es comun difisor de",b,"y",c)
else:
	print(a,"no es comun difisor de",b,"y",c)

def ingresar(XS,n):
	for i in range(n):
		XS.append(int(input("Valor:")))

def sumaPositivos(XS,n):
	b=0
	for i in range(len(XS)):	
		if XS[i]>0:
			b=b+XS[i]
	return b
def productoNegativos(XS,n):	
	b=0	
	c=1
	for i in range(len(XS)):
		if XS[i]<0:
			c=c*XS[i]
			b+=c
	return c
XS=[]
n=10
ingresar(XS,n)
print("La suma es:",sumaPositivos(XS,n)," y el producto es:",productoNegativos(XS,n))

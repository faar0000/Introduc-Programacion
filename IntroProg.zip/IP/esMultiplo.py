def esMultiplo(a,b):
	if a%b==0:
		return True
	return False
a=int(input("Inserte numerador:"))
b=int(input("Inserte divisor:"))
if esMultiplo (a,b)==True:
	print(a,"es multiplo de",b)
else:
	print(a,"no es multiplo de",b)

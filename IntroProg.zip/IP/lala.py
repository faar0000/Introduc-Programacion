xs=[2,3,4,5,6]
ys=[2,3,4,5]
for i in range(len(xs)):
	xs[i]=xs[i]*ys[i]
print(xs)

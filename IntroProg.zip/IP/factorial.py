def factorial(n):
	b=1
	for i in range (1,n+1):
		b=b*i
	return b
def combinatoria(k,n):
	return factorial(n)/(factorial(k)*factorial(n-k))
n=int(input("Inserte numero:"))
k=int(input("Inserte numero:"))
print("N° de combinaciones de",k,"en",n,":",combinatoria(k,n))	
#practica 3 y 4
			

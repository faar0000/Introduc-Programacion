def ingresar(XS,n):
	for i in range(n):
		XS.append(int(input("Valor:")))

def mayorLista(XS,n):	
	b=0
	for i in range(len(XS)):	
		if XS[i]>b:
			b=XS[i]
	return b
def menorLista(XS,n):	
	b=XS[0]
	for i in range(len(XS)):	
		if XS[i]<=b:
			b=XS[i]
	return b

XS=[]
n=int(input("Cantidad de elementos:"))
ingresar(XS,n)
print("El mayor es",mayorLista(XS,n)," Y menor es ",menorLista(XS,n))

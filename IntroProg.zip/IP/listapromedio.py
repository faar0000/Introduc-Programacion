#ingresar n numero enteros a una lista y hallar el promedio
def ingresar(L,n):
	for i in range(n):
		L.append(int(input("Valor:")))
def mostrar(L,n):
	b=0	
	c=0
	for i in L:
		c+=i
		b+=1
	return(c/b)
L=[]
n=int(input("Cantidad de elementos:"))
ingresar(L,n)
print("El promedio de la lista es:",mostrar(L,n))

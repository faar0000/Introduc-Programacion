def mcd(num1, num2):
    a = max(num1, num2)
    b = min(num1, num2)
    while b!=0:
        mcd = b
        b = a%b
        a = mcd
    return mcd

def mcm(num1, num2):
    a = max(num1, num2)
    b = min(num1, num2)
    mcm = (a / mcd(a, b)) * b
    return mcm

class Fraccion:
    def __init__(self,N,D):
        self.N=N
        self.D=D      
    def sumar(self,otherFrac,Res):
        Res.D=self.D*otherFrac.D 
        Res.N=otherFrac.D*self.N+self.D*otherFrac.N
        s = mcd(Res.D,Res.N)
        Res.D//=s
        Res.N//=s
        print("Suma:",Res.N,"/",Res.D)
    def restar(self,otherFrac,Res):
        Res.D=self.D*otherFrac.D 
        Res.N=otherFrac.D*self.N-self.D*otherFrac.N
        s = mcd(Res.D,Res.N)
        Res.D/=s
        Res.N/=s
        print("Resta:",Res.N,Res.D)
    def multiplicar(self,otherFrac,Res):
        Res.D=self.D*otherFrac.D
        Res.N=self.N*otherFrac.N
        s = mcd(Res.D,Res.N)
        Res.D/=s
        Res.N/=s
        print("Multiplicar",Res.N,Res.D)
    def dividir(self,otherFrac,Res):
        Res.D=self.N*otherFrac.D
        Res.N=self.D*self.N
        s = mcd(Res.D,Res.N)
        Res.D//=s
        Res.N//=s
        print("Divicion:",Res.N,"/",Res.D)

    def imprimir(self):
        s = mcd(self.D,self.N)
        self.D//=s
        self.N//=s
        if self.D==1:
            print(self.N)
        else:
            print(self.N,"/",self.D)    


A=Fraccion(3,5)
B=Fraccion(4,7)
C=Fraccion(18,3)
R=Fraccion
S=Fraccion
A.sumar(B,R)
A.dividir(B,S)
C.imprimir()


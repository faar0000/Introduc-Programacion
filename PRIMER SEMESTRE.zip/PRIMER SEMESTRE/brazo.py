import turtle
import time
T=turtle
def hombro():
    T.up()
    T.goto(110,70)
    T.down()
    T.shape("circle")
    T.shapesize(3,5,1)
    T.stamp()
    
def hombro2():
    T.up()
    T.goto(-110,70)
    T.down()
    T.shape("circle")
    T.shapesize(3,5,1)
    T.stamp()
    
def brazo1():
    a=0
    x=-145
    y=-35
    for i in range (40):
        T.up()
        T.goto(x,y)
        T.down()
        T.shape("circle")
        T.shapesize(10,1,1)
        T.tilt(a)
        T.stamp()
        T.clear()
        a-=0.1
        x-=1
        y+=1

hombro()
hombro2()
brazo1()

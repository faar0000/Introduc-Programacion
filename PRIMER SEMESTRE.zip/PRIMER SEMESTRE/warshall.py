def crearMatriz(M,N,B,f,c):
	for i in range(f):
		M.append([0]*c)
	for i in range(f):
		for j in range(c):
			M[i][j]=int(input("Valor:"))
	for i in range(f):
		N.append([0]*c)
	for i in range(f):
		B.append([0]*c)

def mostrarMatriz(N):

	for i in N:
		print (i)
	print("TU MATRIZ WARSHALL FINAL")

def warshall(M,N,B,f,c):

	for k in range (f):
		for i in range (f):
			for j in range (f):
				if M[i][j]==1:
					N[i][j] =1
				if (M[i][k]==1 and M[k][j]==1):
					N[i][j] =1


		M=N

B=[]
N=[]
M=[]
f=int(input("N° de filas:"))
c=int(input("N° de columnas:"))
crearMatriz(M,N,B,f,c)
warshall(M,N,B,f,c)
mostrarMatriz(N)


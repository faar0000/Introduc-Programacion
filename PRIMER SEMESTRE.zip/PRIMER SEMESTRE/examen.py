import math
class Vector:
    def __init__(self,x,y):
        self.x=x
        self.y=y

    def perpendicular(self,otherVector):
        if (self.x*otherVector.x)+(self.y*otherVector.y)==0:
            print ("Profesor aumenteme dos puntos")


A=Vector(3,5)
B=Vector(-5,3)
Res=Vector
A.perpendicular(B)

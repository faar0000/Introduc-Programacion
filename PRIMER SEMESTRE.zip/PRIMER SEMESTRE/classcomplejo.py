import math
class Complejo:
  
        
    def __init__(self,R,I):
        self.R=R
        self.I=I
        
    def suma1(self,otherComplex):
        self.R = self.R+otherComplex.R
        self.I = self.I+otherComplex.I
        print("Suma met1:",self.R,"+",self.I,"i")
    def suma(self,otherComplex,RComplejo):
        RComplejo.R = self.R+otherComplex.R
        RComplejo.I = self.I+otherComplex.I
        print("Suma met2:",RComplejo.R,RComplejo.I)
    def dividir(self,otherComplejo,RComplejo):
        if B.R==0 or B.I==0:
            print("No se puede dividir")
        else:
            RComplejo.R = self.R/otherComplejo.R
            RComplejo.I = self.I/otherComplejo.I
            print("Divide",self.R,self.I)
        
    def argumento(self):
        if self.I==0:
            print("No se puede dividir")
        else:
            print("Argumento",round(math.degrees(math.atan(self.I/self.R))))
        
    def multiplicar(self,otherComplejo):
        otherComplejo.R=(self.R*otherComplejo.R)-(self.I*otherComplejo.I)
        otherComplejo.I=self.I*otherComplejo.I
        print("Multiplicacion:",otherComplejo.R,"+",otherComplejo.I,"i")
    def conjugada(self,otherComplejo):
        otherComplejo.R=self.R
        otherComplejo.I=self.I*-1
        print("COnjudada:",otherComplejo.R,otherComplejo.I)
    def modulo(self):
        print("MODULO:",math.sqrt(self.R**2+self.I**2))
A=Complejo(3,5)
B=Complejo(4,7)
Res=Complejo
#A.suma(B,Res)
B.suma1(A)
#A.dividir(B,Res)
A.argumento()
A.multiplicar(B)
#A.conjugada(Res)
A.modulo()

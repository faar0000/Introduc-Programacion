import turtle
import math
turtle.speed(5)
def triangle(x,y,tam):
    if(tam<10):
        return
    else:
        turtle.up()
        turtle.goto(x,y)
        turtle.down()
        turtle.forward(tam)
        turtle.left(120)
        turtle.forward(tam)
        turtle.left(120)
        turtle.forward(tam)
        turtle.left(120)
        triangle(x,y,tam/2)
        triangle(x+tam/2,y,tam/2)
        triangle(x+tam/4,y+math.sqrt(3)*tam/4,tam/2)

triangle(-200,-200,500)

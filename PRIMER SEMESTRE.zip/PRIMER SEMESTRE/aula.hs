doble :: Integer -> Integer
doble x = 2 * x

cuadruplo :: Integer -> Integer
cuadruplo x = doble (doble x)

 

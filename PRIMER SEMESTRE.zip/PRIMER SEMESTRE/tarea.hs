(|||) :: Bool -> Bool -> Bool 
(|||) True _ = True
(|||) _ True = True
(|||) _ _ = False

operador w x y z = if (w > x && y > z)== False
	 		then "True :: Bool"
			else "False :: Bool"

maximo3 :: Integer -> Integer -> Integer -> Integer
maximo3 x y z
	| x > y && x > z = x
	| y > x && y > z = y
	| otherwise = z

max2 x y = if x>y
		then x
		else y

max3 x y z = max2(max2 x y) z

max4 w x y z = max2 w (max3 x y z)

max5 w x y z = max2 (max2 w x ) (max2 y z)

tresDiferentes x y z = if (x /= y && y/=z)
				then True :: Bool
				else False :: Bool

cuatroIgual w x y z  = if (w==x && x == y && y==z)
				then True
				else False

media3 x y z = (x+y+z)/3



--cuantosSobreMedia3 x y z 
--	
--	| x > media3 x y z = 1
--	| y > media3 x y z && x > media3 x y z = 2
--	| x > media3 x y z && y > media3 x y z && z > media3 x y z = 3	



--2.2
--caso1 :: (a -> b -> b) -> b -> [a] -> b
--caso1 f v [] = v
--caso1 f v (x:xs) = f x (caso1 f v xs)

--2.4
rechaza :: (Int -> Bool) -> [Int] -> [Int]
rechaza p xs = [x | x <- xs , not (p x)]

--2.3
filter2 :: (Int -> Bool) ->[Int] -> [Int]
filter2 p xs = [x | x <- xs, p x]

--2.5
divisible :: Int->Int->Bool 
divisible x y = (mod x y) ==0


--divisoresf :: Int -> [Int]
--divisoresf x = [ y | y <- [1..x], divisible x y]

--2.6
divisores :: Int -> [Int]
divisores x = filter (divisible x) [1..x]


--2.7
mcd :: Int -> Int -> Int
mcd a 0 = a
mcd a b = mcd b (mod a b)

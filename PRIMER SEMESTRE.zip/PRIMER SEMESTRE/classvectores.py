import math
class Vector:
    def __init__(self,x,y):
        self.x=x
        self.y=y
    def suma(self,otherVector,Res):
        Res.x=otherVector.x+self.x
        Res.y=otherVector.y+self.y
        print("Suma:", "(",Res.x,",",Res.y,")")
    def multiplicarC(self,C):
        self.x=self.x*C
        self.y=self.y*C
        print("Multipicacion con C:","(",self.x,",",self.y,")")
    def productoI(self):
        print("Producto I:",self.x*self.y)
    def modulo(self):
        print("Modulo:",math.sqrt(self.x**2+self.y**2))
    def paralelo(self,otherVector):
        if self.x/self.y==otherVector.x/otherVector.y:
            return True
        else:
            return False

    def perpendicular(self,otherVector):
        if self.x*otherVector.x+self.y+otherVector.y==0:
            return True
        else:
            return False
A=Vector(3,5)
B=Vector(7,-2)
Res=Vector
#A.productoI()
print(A.paralelo(B))
A.suma(B,Res)
print(A.perpendicular(B))
#A.modulo()
#A.multiplicarC(2)






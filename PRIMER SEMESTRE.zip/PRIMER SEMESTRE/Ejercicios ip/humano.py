class Humano:
        def __int__(self,edad):
                self.edad=25
                print("soy nuevo objeto")
        def hablar(self,mensaje):
                print(mensaje)
juan=Humano()
sofia=Humano()
print("Soy Juan  y tengo:",juan.edad)
print("Soy Sofia y tengo:",sofia.edad)

juan.hablar("Hola")
sofia.hablar("Hola Juan")

import turtle
T=turtle
def drawojo(x,y,ini):
    T.up()
    T.goto(x,y)
    T.down()
    a=ini/5

    for i in range(3):
        T.circle(ini)
        ini+=a*(i*2+1)

def drawhead(x,y,z):
    T.begin_fill()
    T.fillcolor("orange")
    T.up()
    T.goto(x,y)
    T.down()
    T.circle(z)
    T.end_fill()

def drawface(x,y,z):
    
    drawhead(x,y,z)
    drawojo(x-z/4,y+4*(z/4),z/15)
    drawojo(x+z/4,y+4*(z/4),z/15)
    T.up
    
    
def cuerpo():
    T.up()
    T.goto(0,-40)
    T.down()
    T.shape("circle")
    T.shapesize(15,11,1)
    T.stamp()
    
def hombro():
    T.up()
    T.goto(110,70)
    T.down()
    T.shape("circle")
    T.shapesize(3,5,1)
    T.stamp()
    
def hombro2():
    T.up()
    T.goto(-110,70)
    T.down()
    T.shape("circle")
    T.shapesize(3,5,1)
    T.stamp()
    
def brazo1():
    T.up()
    T.goto(-145,-35)
    T.down()
    T.shape("circle")
    T.shapesize(12,3,1)
    T.stamp()
    
def brazo2():
    T.up()
    T.goto(145,-35)
    T.down()
    T.shape("circle")
    T.shapesize(12,3,1)
    T.stamp()
    
def pierna():
    T.up()
    T.goto(50,-260)
    T.down()
    T.shape("circle")
    T.shapesize(12,3,1)
    T.stamp()
    
def pierna2():
    T.up()
    T.goto(-50,-260)
    T.down()
    T.shape("circle")
    T.shapesize(12,3,1)
    T.stamp()

def dedos1():
    x=-121
    y=-123
    z=20
    for i in range(5):
        T.up()  
        T.goto(x,y)
        T.down()
        T.shape("circle")
        T.shapesize(0.8,0.3,1)
        T.tilt(z)
        T.stamp()
        x=x-5
        z=z-5
        y=y-8
def dedos2():
    x=118
    y=-123
    z=20
    for i in range(5):
        T.up()  
        T.goto(x,y)
        T.down()
        T.shape("circle")
        T.shapesize(0.8,0.3,1)
        T.tilt(z)
        T.stamp()
        x=x+5
        z=z-5
        y=y-8
def pie1():
    T.up()
    T.goto(-94,-365)
    T.down()
    T.shape("circle")
    T.shapesize(2,6,1)
    T.stamp()
def pie2():
    T.up()
    T.goto(94,-365)
    T.down()
    T.shape("circle")
    T.shapesize(2,6,1)
    T.stamp()
def cabello():
    z=110
    for i in range (5):
        x=-4
        T.up()
        while x<3:
            T.goto(x**3+x**2+x+z,x*10+320)
            T.down()
            T.forward(1)
            x+=0.1
        z=z-30
def mitadcirculo(x):
    T.up()
    T.goto(-20,180)
    T.down()
    T.rt(90)
    T.circle(x,180)
    T.lt(90)
    T.fd(2*x)
def tatuaje():
    T.up()
    T.goto(-10,50)
    T.down()
    T.write("holaa",font=("Arial",20,"normal"))
drawface(0,100,100)
mitadcirculo(20)
cabello()
cuerpo()
hombro()
hombro2()
brazo1()
brazo2()
pierna()
pierna2()
pie1()
pie2()
dedos1()
dedos2()
tatuaje()


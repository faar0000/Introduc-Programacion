def fecha(d,m,y):
	xs = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
	print (d,'de',xs[m-1],y)
fecha = str(input("Fecha (dia/mes/año):"))
if fecha[0] == str(0):
	d=fecha[1]
else:
	d=fecha[0:2]

if fecha[3]==str(0):
	m=fecha[4]
else:
	m=fecha[3:5]
y=fecha[6:]

fecha(int(d),int(m),int(y))

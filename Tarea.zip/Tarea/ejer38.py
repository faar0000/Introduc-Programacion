archivo_texto = open("texto","r")
lineas = archivo_texto.readlines()
archivo_texto.close
def contar(xs):
	contMayusc = 0
	contMinus = 0
	contDigitos = 0
	contBlanks = 0
	for i in xs:
		if 65 <= ord(i) <= 90:
			contMayusc += 1
		if 97 <= ord(i) <= 122:
			contMinus += 1
		if i == ' ':
			contBlanks += 1
		contDigitos += 1
	return [contMayusc,contMinus,contDigitos,contBlanks]

info_Lineas = []
for i in lineas:
	info_Lineas.append(contar(i))
# print(info_Lineas) solo de verificacion

def suma_ListadeLista(xs): # Esta función suma los elementos de una lista de listas
						   # Suponiendo que todos son iguales
	total = [0,0,0,0]
	for j in range(4):
		for i in range(len(xs)):
			total[j] += xs[i][j]

	return total

# print(suma_ListadeLista(info_Lineas)) sólo de verificación

def mostrarMensaje(xs):
	print("Se han contado",xs[0],"Letras Mayusculas")
	print("Se han contado",xs[1],"Letras Minusculas")
	print("Se han contado",xs[2],"Dígitos")
	print("Se han contado",xs[3],"Espacios en blanco")

print("Del archivo",archivo_texto)
mostrarMensaje(suma_ListadeLista(info_Lineas))


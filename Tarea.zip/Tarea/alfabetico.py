def alfabetico(xs):
	for i in range(len(xs)-1):
		if xs[i]>xs[i+1]:
			return False
		else:
			return True
xs=str(input("Ingrese palabra:"))
print(alfabetico(xs))

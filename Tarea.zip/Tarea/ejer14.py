def gastos(x):
    y = 0
    z = input("Ingrese sus gastos del mes (S para salir):")
    if z == "S" or gastos == "s":
        print("No se ingresaron datos")
    else:
        while z != "S" and z != "s":
            y += int(z)
            z = input("Ingrese sus gastos del mes (S para salir):")
 
        if x < y:
            print("El total gastado esta por encima del Presupuestado")
 
        if x == y:
            print("El total gastado es igual al Presupuestado")
 
        if x > y:
            print("El total gastado esta por debajo del Presupuestado")
 
x = int(input("Ingrese el Monto total Presupuestado:"))
 
gastos(x)

#Escribe un programa que lea tres cadenas y muestre el prefijo común más
#largo de todas ellas. Ejemplo: las cadenas ’politecnico’, ’polinizacion’ y
#’poros’ tienen como prefijo comun más largo a la cadena ’po’.

def tamaño(XS,YS,ZS,M):
	if len(XS)<len(YS) and len(XS)<len(ZS):
		M=XS
		return M
	elif len(YS)<len(XS) and len(YS)<len(ZS):
		M=YS
		return M
	elif len(ZS)<len(XS) and len(ZS)<len(YS):
		M=ZS
		return M
def leer(XS,YS,ZS,M):
	F=[]
	for i in range(len(M)):
		if XS[i]==YS[i] and XS[i]==ZS[i]:
			F.append(XS[i])
		else:
			break
	print(F)
M=[]
XS=str(input("Palabra 1:"))
YS=str(input("Palabra 2:"))
ZS=str(input("Palabra 3:"))

M=tamaño(XS,YS,ZS,M)

leer(XS,YS,ZS,M)


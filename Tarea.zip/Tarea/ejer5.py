def romano(x):
	if x>=1 and x<=10:
		if x==1:
			return "I"
		elif x==2:
			return "II"
		elif x==3:
			return "III"
		elif x==4:
			return "IV"
		elif x==5:
			return "V"
		elif x==6:
			return "VI"
		elif x==7:
			return "VII"
		elif x==8:
			return "VIII"
		elif x==9:
			return "IX"
		elif x==10:
			return "X"
	else:
		return "No esta en el rango, ahorita no joven"

x=int(input("Ingrese numero entre 1 y 10:"))
print("Equivale",romano(x))

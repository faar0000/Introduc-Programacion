def matrices(XS):
	for i in XS:
		for j in i:
			print(j, end = " ")
		print(" ")
XS=([1,2,3],[4,5,6],[7,8,9],[0,1,2])
matrices(XS)

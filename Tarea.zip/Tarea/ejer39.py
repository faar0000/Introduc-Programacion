def separadorPalabras(xs):
	palabras = []
	cont1 = 0
	cont2 = 0
	for i in xs:
		if i == ' ':
			palabras.append(xs[cont2:cont1])
			cont2 = cont1 + 1
		cont1 += 1
	palabras.append(xs[cont2:])
	print(palabras)
	return palabras

def c(xs,posc):
	a = xs[posc]
	cont = 0
	for i in xs:
		if a == i:
			cont += 1
	return [cont,a]

def buscar(xs,elemento): # busca un elemento en la lista
	for i in xs:
		if i == elemento:
			return True
	return False

texto = str(input("Ingrese el texto a analizar: "))

list1 = separadorPalabras(texto)
list2 = []

for i in range(len(list1)):
	if not buscar(list2,c(list1,i)):
		list2.append(c(list1,i))
print(list2)

# buscar el mayor de la lista2
mayorlista = list2[0]
mayor = list2[0][0]
for i in range(len(list2)):
	if mayor < list2[i][0]:
		mayor = list2[i][0]
		mayorlista = list2[i]

print("La palabra que mas repite es", mayorlista[1], "con", mayorlista[0], "repeticiones")





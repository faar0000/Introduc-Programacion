def ingresar(XS,n):
	for i in range(n):
		XS.append(int(input("Valor:")))
def mayorLista(XS):	
	b=0
	for i in range(len(XS)):	
		if XS[i]>b:
			b=XS[i]
	return b
def menorLista(XS):	
	b=0
	for i in range(len(XS)):	
		if XS[i]<=b:
			b=XS[i]
	return b
def promedio(XS):	
	c=0
	for i in XS:
		c+=i
	return "Total de la lista:",c,"Promedio es:",(c/20)
XS=[]
n=20
ingresar(XS,n)
print("Mayor de la lista",mayorLista(XS))
print("Menor de la lista",menorLista(XS))
promedio(XS)



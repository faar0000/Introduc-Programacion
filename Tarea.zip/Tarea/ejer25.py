import random
def juego():
	x=random.randint(1,3)
	if x==1:
		x="piedra"
	elif x==2:
		x="papel"
	elif x==3:
		x="tijeras"
	y=str(input("Elija entre piedra,papel o tijera:"))
	print ("La computadora elijio",x)	
	if y=="piedra" and x=="papel":
		print ("Pierdes")
	elif y=="papel" and x=="piedra":
		print ("Has ganado")
	elif y=="tijeras"and x=="papel":
		print ("Has ganado")
	elif x=="papel" and y=="piedra":
		print ("Has perdido")
	elif x=="tijeras"and y=="papel":
		print ("Has perdido")
	elif x=="piedra" and y=="tijeras":
		print ("Has perdido")	
	elif x==y:
		return "empate",juego()
print("Bienvenido al Juego de Piedra, Papel o Tijeras")
juego()





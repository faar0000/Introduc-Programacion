def paquetes(x,y):
	if x>=10:
		if x<=19:
			y=x*y
			x=y*(20/100)
			y=y-x
			return "Su descuento es de",x,"Tendra que pagar",y
		elif x>19 and x<=49:
			y=x*y
			x=y*(30/100)
			y=y-x
			return "Su descuento es de",x,"Tendra que pagar",y
		elif x>=50 and x<=99:
			y=x*y
			x=y*(40/100)
			y=y-x
			return "Su descuento es de",x,"Tendra que pagar",y
		elif x>=100:
			y=x*y
			x=y*(50/100)
			y=y-x
			return "Su descuento es de",x,"Tendra que pagar",y
	else:
		return("NO HAY DESCUENTO PARA SU CANTIDAD")
y=99
x=int(input("Numero de paquetes comprados:"))

print (paquetes(x,y))

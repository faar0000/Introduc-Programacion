def listaprimos():
	n=1
	while n<=100:
		div=0	
		for i in range(1,n+1):
			if n%i==0:
				div+=1
		if div <=2:
			print(n,end=" ")
		n+=1
	print(" ")
listaprimos()

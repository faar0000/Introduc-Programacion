def alfabetico(xs):
	b=0
	for i in range(len(xs)):

		if xs[i]>"a":
			return True
		else:
			return False
			

		
xs=str(input("Ingrese palabra:"))
print(alfabetico(xs))


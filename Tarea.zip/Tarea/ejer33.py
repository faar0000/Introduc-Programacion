def lista_respuestas():
	xs = []
	for i in range(1,21):
		msj1 = "Ingrese la respuesta para la Pregunta " + str(i) + ":"
		respuesta = str(input(msj1))
		xs.append(respuesta)
	return xs

clave = ['B', 'D', 'A', 'A', 'C', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A']

datos = open('Datos','r')
lineas = datos.readlines() # genera una lista como ['A\n', 'A\n', 'A\n', 'A\n', ... , A\n] 
						   # con las claves del estudiante
datos.close()

claveEstudiante = []

for i in lineas:
	claveEstudiante.append(i[0]) # asi solo se agregan los primeros caracteres de cada linea

def calificacion(clave,claveEstudiante): # suponemos que ambas listas tienen el mismo tamaño
					  # para nuestro caso de 20
	respuestasCorrectas = 0
	preguntasIncorrectas = []
	for i in range(20):
		if clave[i] == claveEstudiante[i]:
			respuestasCorrectas += 1
		else:
			preguntasIncorrectas.append(i+1)

	respuestasIncorrectas = 20 - respuestasCorrectas

	if respuestasCorrectas >= 15:
		print("El estudiante aprobó el examen!")
	else:
		print("Lo sentimos el estudiante desaprobó")

	print("Respuestas Correctas: ", respuestasCorrectas)
	print("Respuestas Incorrectas: ", respuestasIncorrectas)
	print("Preguntas Incorrectas: ",preguntasIncorrectas)

calificacion(clave,claveEstudiante)

# Este es solo un ejemplo de manejo de archivos desde python

# def creartxt():
#     archi=open('datos.txt','w')
#     archi.close()

# def grabartxt():
#     archi=open('datos.txt','a')
#     archi.write('Linea 1\n')
#     archi.write('Linea 2\n')
#     archi.write('Linea 3\n')
#     archi.close()

# def leertxtenlista():
#     archi=open('datos.txt','r')
#     lineas=archi.readlines()
#     print (lineas)
#     archi.close()

# creartxt()
# grabartxt()
# leertxtenlista()

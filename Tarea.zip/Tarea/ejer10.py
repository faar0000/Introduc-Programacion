def lista(xs):
	for i in range(1,101):
		xs.append(i*10)
	return xs
xs=[]
print(lista(xs))

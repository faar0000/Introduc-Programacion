def copiar(xs,ys):
    for i in xs:
        ys.append(i)
 
    return ys
 
xs = list(range(100))
ys = []
 
print("Lista principal", xs)
print("copiar a", ys)
print("La copia es", copiar(xs,ys))

def comparacion(x,y,z):
	if z==x*y:
		return("Es magico")
	else:
		return("No es magico")




x=int(input("Ingrese dia:"))
y=int(input("Ingrese mes:"))
z=int(input("Ingrese año de dos digitos:"))

print(comparacion(x,y,z))

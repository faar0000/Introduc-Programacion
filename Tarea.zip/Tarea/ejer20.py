def dibujo(n):
    for i in range(n):
        print ("#"+(" " * i)+"#")
 
n = int(input("Ingrese el numero:"))
 
dibujo(n)

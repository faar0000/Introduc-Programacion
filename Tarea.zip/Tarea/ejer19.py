def triangulo(n):
    for i in range(n,0,-1):
        print ("* " * i)
 
n = int(input("Ingrese el numero:"))
 
triangulo(n)

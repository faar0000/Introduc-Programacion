def puntos(x):
	if x>=0 and x<=4:
		if x==0:
			return "0 puntos"
		elif x==1:
			return "5 puntos"
		elif x==2:
			return "15 puntos"
		elif x==3:
			return "30 puntos"
		elif x==4:
			return "60 puntos"
	else:
		return("Cantidad no aceptada")
x=int(input("Numero de libros al mes:"))

print(puntos(x))

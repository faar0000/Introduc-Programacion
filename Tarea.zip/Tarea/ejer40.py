def separador(xs):
	p=[]
	cont1 = 0
	cont2 = 0
	for i in xs:
		if i == ' ':
			p.append(xs[cont2:cont1])
			cont2 = cont1 + 1
		cont1 += 1
	p.append(xs[cont2:])
	print(p)
	return p

def latin_Pig(xs):
	aux1 = xs[0]
	xs = xs[1:]
	aux2 = 'AY'
	xs += aux1 + aux2
	return xs

t= str(input("Ingrese el texto:"))
listaPalabras = separador(t)
latinPig = []
for i in listaPalabras:
	latinPig.append(latin_Pig(i))
print(latinPig)

for i in latinPig:
	print(i, end = " ")
print(" ")

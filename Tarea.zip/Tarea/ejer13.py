def calorias(XS):
	YS=[]
	for i in range(len(XS)):
		YS.append(XS[i]*(3.9))		
	return YS
XS=[10,15,20,25,30,40,50,60]
print("Se queman",calorias(XS),"calorias")

def ingresar(L,n):
	c=0.10
	for i in range(n):
		L.append(c)
		c=c*2
def mostrar(L,n):
	for i in range(n):
		print(L[i])
def suma(L,n):
	c=0
	for i in range(len(L)):
		c+=L[i]
	return c


L=[]
n=int(input("Dias a trabajar:"))
ingresar(L,n)
print("Ganancia por dia:")
mostrar(L,n)
print("Ganancia total:",suma(L,n))


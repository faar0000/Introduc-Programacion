def interes(p,i,t):
	f=p*(1+i)**t
	return f
p=int(input("Su dinero actual es:"))
i=int(input("Tasa de interes es:"))
t=int(input("Meses que el dinero estara en la cuenta:"))

print("Su dinero sera:",interes(p,i,t))



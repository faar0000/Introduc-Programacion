def sigla(n):
	x=[]+[n[0]]
	for i in range(len(n)):
		if n[i] == ' ':
			x.append(n[i+1])
	for i in x:
		print (i, end = "")
	print("")
	return x
n=str(input("Nombre:"))
sigla(n)



def lluvia(x):
	c=x*12
	b=0

	for i in range(x):
		for j in range(12):
			y=int(input("Pulgadas de lluvia para el mes:"))
			b+=y
	return "Meses:",c,"Total de pulgadas",b,"Promedio:",(b/c)


x=int(input("Años:"))
print(lluvia(x))

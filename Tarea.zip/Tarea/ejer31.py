def lluvia(XS):
	b=0
	for i in range(12):
		y=int(input("Precipitacion acuosa mes:"))
		XS.append(y)
		b+=y
	return "Precipitacion acuosa total",b,"Promedio:",(b/12)

def mayorLista(XS):	
	b=0
	for i in range(len(XS)):	
		if XS[i]>b:
			b=XS[i]
	return b
def menorLista(XS):	
	b=XS[0]
	for i in range(len(XS)):	
		if XS[i]<=b:
			b=XS[i]
	return b
XS=[]
lluvia(XS)
print("Maryor precipitacion acuosa:",mayorLista(XS))
print("Menor precipitacion acuosa:",menorLista(XS))

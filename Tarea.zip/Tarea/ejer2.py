# 1 topo 3, 333.00
def convertir(x):
	x=x/3333
	return x
x=int(input("Ingrese numero:"))
print("Equivale a",convertir(x),"topos")

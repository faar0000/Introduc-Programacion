def ordenar(XS,x):
	XS.append(x)	
	XS.sort()
	return XS

XS=[1,2,6,9]
x=int(input("Ingrese numero:"))
print("Nueva lista es:",ordenar(XS,x))

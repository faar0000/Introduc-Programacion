def insectos(x):
	c=0
	for i in range (x):
		c+=int(input("Ingrese N°de insectos:"))
	return c			

x=7
print("Total de insectos recogidos en la semana",insectos(x))

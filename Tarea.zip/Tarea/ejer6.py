def colores(x,y):
	if x=="azul" or x=="rojo" or x=="amarillo"and y=="azul" or y=="rojo" or y=="amarillo":
		if x=="azul" or x=="rojo" and y=="rojo" or y=="azul":
			return "purpura"
		elif x=="azul" or x=="amarillo" and y=="amarillo" or y=="azul":
			return "verde"
		elif x=="rojo" or x=="amarillo" and y=="amarillo" or y=="rojo":
			return "naranja"
		elif x=="azul" or x=="amarillo" and y=="amarillo" or y=="azul":
			return "verde"
	else:
		return("Alguno no es color primario")
x=input("Color 1:")
y=input("Color 2:")
print(colores(x,y))



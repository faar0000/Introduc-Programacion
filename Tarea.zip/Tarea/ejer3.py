def distancia(x):
	y=0	
	y=80*x
	return y



x=int(input("Ingrese tiempo en horas:"))
print("Equivale a",distancia(x),"Km")

import random
def loteria(XS):
	for i in range(7):
		c=random.randint(0,9)
		XS.append(c)
	return XS
XS=[]
print("Numero de boleto es:",loteria(XS))

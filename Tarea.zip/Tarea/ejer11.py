def lista(c):
	a=1
	b=30
	for i in range(1,31):
		c+=(a/b)
		a+=1
		b-=1
	return c
c=0
print(lista(c))

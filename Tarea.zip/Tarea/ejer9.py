def bucle(n):
    producto = n
    if n > 0:
        while producto * 10 < 100:
            producto *= 10
        return producto
    else:
        print("Critical Error")
 
n = int(input("Ingrese un número: "))
 
print(bucle(n))

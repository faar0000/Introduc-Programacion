def ingrese(x):
	x=x*23/100
	return x

x=int(input("Ingrese numero:"))

print("El ingreso es igual:",ingrese(x))

def sumatoria():
    sumatoria = 0
    n = int(input("Ingrese un número positivo (negativo para finalizar): "))
    while n >= 0:
        sumatoria += n
        n = int(input("Ingrese un número positivo (negativo para finalizar): "))
    print("La sumatoria es:", sumatoria)
    return sumatoria
     
sumatoria()
		

###########ejer1.py###########

def ejer1():
	def ingrese(x):
		x=x*23/100
		return x
	
	x=int(input("Ingrese numero:"))
	
	print("El ingreso es igual:",ingrese(x))


###########ejer2.py###########

def ejer2():
	# 1 topo 3, 333.00
	def convertir(x):
		x=x/3333
		return x
	x=int(input("Ingrese numero:"))
	print("Equivale a",convertir(x),"topos")




###########ejer3.py###########

def ejer3():
	def distancia(x):
		y=0	
		y=80*x
		return y
	
	
	
	x=int(input("Ingrese tiempo en horas:"))
	print("Equivale a",distancia(x),"Km")


###########ejer4.py###########

def ejer4():
	def comparacion(x,y,z):
		if z==x*y:
			return("Es magico")
		else:
			return("No es magico")
	
	
	
	
	x=int(input("Ingrese dia:"))
	y=int(input("Ingrese mes:"))
	z=int(input("Ingrese año de dos digitos:"))
	
	print(comparacion(x,y,z))


###########ejer5.py###########

def ejer5():
	def romano(x):
		if x>=1 and x<=10:
			if x==1:
				return "I"
			elif x==2:
				return "II"
			elif x==3:
				return "III"
			elif x==4:
				return "IV"
			elif x==5:
				return "V"
			elif x==6:
				return "VI"
			elif x==7:
				return "VII"
			elif x==8:
				return "VIII"
			elif x==9:
				return "IX"
			elif x==10:
				return "X"
		else:
			return "No esta en el rango, ahorita no joven"
	
	x=int(input("Ingrese numero entre 1 y 10:"))
	print("Equivale",romano(x))




###########ejer6.py###########

def ejer6():
	def colores(x,y):
		if x=="azul" or x=="rojo" or x=="amarillo"and y=="azul" or y=="rojo" or y=="amarillo":
			if x=="azul" or x=="rojo" and y=="rojo" or y=="azul":
				return "purpura"
			elif x=="azul" or x=="amarillo" and y=="amarillo" or y=="azul":
				return "verde"
			elif x=="rojo" or x=="amarillo" and y=="amarillo" or y=="rojo":
				return "naranja"
			elif x=="azul" or x=="amarillo" and y=="amarillo" or y=="azul":
				return "verde"
		else:
			return("Alguno no es color primario")
	x=input("Color 1:")
	y=input("Color 2:")
	print(colores(x,y))
	
	


###########ejer7.py###########

def ejer7():
	def puntos(x):
		if x>=0 and x<=4:
			if x==0:
				return "0 puntos"
			elif x==1:
				return "5 puntos"
			elif x==2:
				return "15 puntos"
			elif x==3:
				return "30 puntos"
			elif x==4:
				return "60 puntos"
		else:
			return("Cantidad no aceptada")
	x=int(input("Numero de libros al mes:"))
	
	print(puntos(x))



###########ejer8.py###########

def ejer8():
	def paquetes(x,y):
		if x>=10:
			if x>=10 and x<=19:
				y=x*y
				x=y*(20/100)
				y=y-x
				return "Su descuento es de",x,"Tendra que pagar",y
			elif x>=19 and x<=49:
				y=x*y
				x=y*(30/100)
				y=y-x
				return "Su descuento es de",x,"Tendra que pagar",y
			elif x>=50 and x<=99:
				y=x*y
				x=y*(40/100)
				y=y-x
				return "Su descuento es de",x,"Tendra que pagar",y
			elif x>=100:
				y=x*y
				x=y*(50/100)
				y=y-x
				return "Su descuento es de",x,"Tendra que pagar",y
		else:
			return("NO HAY DESCUENTO PARA SU CANTIDAD")
	y=99
	x=int(input("Numero de paquetes comprados:"))
	
	print (paquetes(x,y))


###########ejer9.py###########

def ejer9():
	def bucle(n):
	    producto = n
	    if n > 0:
	        while producto * 10 < 100:
	            producto *= 10
	        return producto
	    else:
	        print("Critical Error")
	 
	n = int(input("Ingrese un número: "))
	 
	print(bucle(n))


###########ejer10.py###########

def ejer10():
	def lista(xs):
		for i in range(1,101):
			xs.append(i*10)
		return xs
	xs=[]
	print(lista(xs))


###########ejer11.py###########

def ejer11():
	def lista(c):
		a=1
		b=30
		for i in range(1,31):
			c+=(a/b)
			a+=1
			b-=1
		return c
	c=0
	print(lista(c))


###########ejer12.py###########

def ejer12():
	def insectos(x):
		c=0
		for i in range (x):
			c+=int(input("Ingrese N°de insectos:"))
		return c			
	
	x=7
	print("Total de insectos recogidos en la semana",insectos(x))


###########ejer13.py###########

def ejer13():
	def calorias(XS):
		YS=[]
		for i in range(len(XS)):
			YS.append(XS[i]*(3.9))		
		return YS
	XS=[10,15,20,25,30,40,50,60]
	print("Se queman",calorias(XS),"calorias")


###########ejer14.py###########

def ejer14():
	def gastos(x):
	    y = 0
	    z = input("Ingrese sus gastos del mes (S para salir):")
	    if z == "S" or gastos == "s":
	        print("No se ingresaron datos")
	    else:
	        while z != "S" and z != "s":
	            y += int(z)
	            z = input("Ingrese sus gastos del mes (S para salir):")
	 
	        if x < y:
	            print("El total gastado esta por encima del Presupuestado")
	 
	        if x == y:
	            print("El total gastado es igual al Presupuestado")
	 
	        if x > y:
	            print("El total gastado esta por debajo del Presupuestado")
	 
	x = int(input("Ingrese el Monto total Presupuestado:"))
	 
	gastos(x)


###########ejer15.py###########

def ejer15():
	def ordenar(XS,x):
		XS.append(x)	
		XS.sort()
		return XS
	
	XS=[1,2,6,9]
	x=int(input("Ingrese numero:"))
	print("Nueva lista es:",ordenar(XS,x))


###########ejer16.py###########

def ejer16():
	def lluvia(x):
		c=x*12
		b=0
	
		for i in range(x):
			for j in range(12):
				y=int(input("Pulgadas de lluvia para el mes:"))
				b+=y
		return "Meses:",c,"Total de pulgadas",b,"Promedio:",(b/c)
	
	
	x=int(input("Años:"))
	print(lluvia(x))


###########ejer17.py###########

def ejer17():
	def ingresar(L,n):
		c=0.10
		for i in range(n):
			L.append(c)
			c=c*2
	def mostrar(L,n):
		for i in range(n):
			print(L[i])
	def suma(L,n):
		c=0
		for i in range(len(L)):
			c+=L[i]
		return c
	
	
	L=[]
	n=int(input("Dias a trabajar:"))
	ingresar(L,n)
	print("Ganancia por dia:")
	mostrar(L,n)
	print("Ganancia total:",suma(L,n))
	


###########ejer18.py###########

def ejer18():
	def sumatoria():
	    sumatoria = 0
	    n = int(input("Ingrese un número positivo (negativo para finalizar): "))
	    while n >= 0:
	        sumatoria += n
	        n = int(input("Ingrese un número positivo (negativo para finalizar): "))
	    print("La sumatoria es:", sumatoria)
	    return sumatoria
	     
	sumatoria()
			


###########ejer19.py###########

def ejer19():
	def triangulo(n):
	    for i in range(n,0,-1):
	        print ("* " * i)
	 
	n = int(input("Ingrese el numero:"))
	 
	triangulo(n)

###########ejer20.py###########

def ejer20():
	def dibujo(n):
	    for i in range(n):
	        print ("#"+(" " * i)+"#")
	 
	n = int(input("Ingrese el numero:"))
	 
	dibujo(n)


###########ejer21.py###########

def ejer21():
	def failling_distrance(time):
	    g=9.8
	    d=g*time**2/ 2
	    return d
	print("Tiempo(s)\tDistancia(m)")
	 
	for i in range(1,11):
	    print(str(i) + " s\t\t" + str((failling_distrance(i))))


###########ejer22.py###########

def ejer22():
	import random
	 
	def par(xs):
	    par= 0
	    impar= 0
	    for i in xs:
	        if i % 2 == 0:
	            par+= 1
	        else:
	            impar+= 1
	    print("Se han contado",par, "números pares y",impar, "números impares")
	 
	xs = []
	for i in range(100):
	    xs.append(random.randint(1,10))
	 
	print(xs)
	 
	par(xs)


###########ejer23.py###########

def ejer23():
	def listaprimos():
		n=1
		while n<=100:
			div=0	
			for i in range(1,n+1):
				if n%i==0:
					div+=1
			if div <=2:
				print(n,end=" ")
			n+=1
		print(" ")
	listaprimos()


###########ejer24.py###########

def ejer24():
	def interes(p,i,t):
		f=p*(1+i)**t
		return f
	p=int(input("Su dinero actual es:"))
	i=int(input("Tasa de interes es:"))
	t=int(input("Meses que el dinero estara en la cuenta:"))
	
	print("Su dinero sera:",interes(p,i,t))
	
	


###########ejer25.py###########

def ejer25():
	import random
	def juego():
		x=random.randint(1,3)
		if x==1:
			x="roca"
		elif x==2:
			x="papel"
		elif x==3:
			x="tijeras"
		y=str(input("Elija entre piedra,papel o tijera:"))
		print ("La computadora elijio",x)	
		if y=="piedra" and x=="papel":
			print ("Pierdes")
		elif y=="papel" and x=="roca":
			print ("Has ganado")
		elif y=="tijera"and x=="papel":
			print ("Has ganado")
		elif x=="papel" and y=="roca":
			print ("Has perdido")
		elif x=="tijeras"and y=="papel":
			print ("Has ganado")
		elif x=="roca" and y=="tijeras":
			print ("Has ganado")
		elif x==y:
			return "empate",juego()
	print("Bienvenido al Juego de Piedra, Papel o Tijeras")
	juego()
	
	
	
	


###########ejer26.py###########

def ejer26():
	file_object = open("number_list.txt", "w")
	
	a = ""
	for i in range(1,101):
		a += str(i) + " "
	
	file_object.write(a)
	
	file_object.close()


###########ejer27.py###########

def ejer27():
	def copiar(xs,ys):
	    for i in xs:
	        ys.append(i)
	 
	    return ys
	 
	xs = list(range(100))
	ys = []
	 
	print("Lista principal", xs)
	print("copiar a", ys)
	print("La copia es", copiar(xs,ys))


###########ejer28.py###########

def ejer28():
	def listaBusqueda(XS,x):	
		for i in range(len(XS)):	
			if XS[i]==x:
				return True
		return False
	
	XS=[2,-7,3,8,10]
	x=int(input("Bucar numero:")
	print(listaBusqueda(XS,x))


###########ejer29.py###########

def ejer29():
	def matrices(XS):
		for i in XS:
			for j in i:
				print(j, end = " ")
			print(" ")
	XS=([1,2,3],[4,5,6],[7,8,9],[0,1,2])
	matrices(XS)


###########ejer30.py###########

def ejer30():
	import random
	def loteria(XS):
		for i in range(7):
			c=random.randint(0,9)
			XS.append(c)
		return XS
	XS=[]
	print("Numero de boleto es:",loteria(XS))


###########ejer31.py###########

def ejer31():
	def lluvia(XS):
		b=0
		for i in range(12):
			y=int(input("Precipitacion acuosa mes:"))
			XS.append(y)
			b+=y
		return "Precipitacion acuosa total",b,"Promedio:",(b/12)
	
	def mayorLista(XS):	
		b=0
		for i in range(len(XS)):	
			if XS[i]>b:
				b=XS[i]
		return b
	def menorLista(XS):	
		b=XS[0]
		for i in range(len(XS)):	
			if XS[i]<=b:
				b=XS[i]
		return b
	XS=[]
	lluvia(XS)
	print("Maryor precipitacion acuosa:",mayorLista(XS))
	print("Menor precipitacion acuosa:",menorLista(XS))


###########ejer32.py###########

def ejer32():
	def ingresar(XS,n):
		for i in range(n):
			XS.append(int(input("Valor:")))
	def mayorLista(XS):	
		b=0
		for i in range(len(XS)):	
			if XS[i]>b:
				b=XS[i]
		return b
	def menorLista(XS):	
		b=0
		for i in range(len(XS)):	
			if XS[i]<=b:
				b=XS[i]
		return b
	def promedio(XS):	
		c=0
		for i in XS:
			c+=i
		return "Total de la lista:",c,"Promedio es:",(c/20)
	XS=[]
	n=20
	ingresar(XS,n)
	print("Mayor de la lista",mayorLista(XS))
	print("Menor de la lista",menorLista(XS))
	promedio(XS)
	
	


###########ejer33.py###########

def ejer33():
	def lista_respuestas():
		xs = []
		for i in range(1,21):
			msj1 = "Ingrese la respuesta para la Pregunta " + str(i) + ":"
			respuesta = str(input(msj1))
			xs.append(respuesta)
		return xs
	
	clave = ['B', 'D', 'A', 'A', 'C', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A']
	
	datos = open('Datos','r')
	lineas = datos.readlines() # genera una lista como ['A\n', 'A\n', 'A\n', 'A\n', ... , A\n] 
							   # con las claves del estudiante
	datos.close()
	
	claveEstudiante = []
	
	for i in lineas:
		claveEstudiante.append(i[0]) # asi solo se agregan los primeros caracteres de cada linea
	
	def calificacion(clave,claveEstudiante): # suponemos que ambas listas tienen el mismo tamaño
						  # para nuestro caso de 20
		respuestasCorrectas = 0
		preguntasIncorrectas = []
		for i in range(20):
			if clave[i] == claveEstudiante[i]:
				respuestasCorrectas += 1
			else:
				preguntasIncorrectas.append(i+1)
	
		respuestasIncorrectas = 20 - respuestasCorrectas
	
		if respuestasCorrectas >= 15:
			print("El estudiante aprobó el examen!")
		else:
			print("Lo sentimos el estudiante desaprobó")
	
		print("Respuestas Correctas: ", respuestasCorrectas)
		print("Respuestas Incorrectas: ", respuestasIncorrectas)
		print("Preguntas Incorrectas: ",preguntasIncorrectas)
	
	calificacion(clave,claveEstudiante)
	
	# Este es solo un ejemplo de manejo de archivos desde python
	
	# def creartxt():
	#     archi=open('datos.txt','w')
	#     archi.close()
	
	# def grabartxt():
	#     archi=open('datos.txt','a')
	#     archi.write('Linea 1\n')
	#     archi.write('Linea 2\n')
	#     archi.write('Linea 3\n')
	#     archi.close()
	
	# def leertxtenlista():
	#     archi=open('datos.txt','r')
	#     lineas=archi.readlines()
	#     print (lineas)
	#     archi.close()
	
	# creartxt()
	# grabartxt()
	# leertxtenlista()


###########ejer34.py###########

def ejer34():
	campeones = open("CampeonesChampions","r")
	lineas = campeones.readlines()
	campeones.close() # 0 1 4 5 8 9
	
	i = 0
	baseCampeones = []
	while i < len(lineas):
		aux = []
		aux.append(lineas[i][0:7])
		cont1 = 0
		cont2 = 0
		for j in lineas[i + 1]:
			if j == ' ':
				cont1 += 1
			cont2 += 1
			if cont1 == 3:
				break
		cont1 = 0
		cont3 = 0
		for j in lineas[i + 1]:
			if j == '\t': # el python lee este tipo de caracter como uno solo
				cont1 += 1
			cont3 += 1
			if cont1 == 2:
				break
	
		aux.append(lineas[i+1][cont2:cont3-2])
		# print (aux) solo de verificación
		baseCampeones.append(aux)
		i += 4
	buscar = str(input("Ingrese el Equipo de su interes: "))
	cont1 = 0
	for i in baseCampeones:
		if i[1] == buscar:
			cont1 += 1
	
	if cont1 == 0:
		print ("El Equipo no ha ganado ni un torneo, o escribió mal el nombre")
	else:
		print("Su equipo ha ganado", cont1, "veces la Champions")


###########ejer35.py###########

def ejer35():
	def sigla(n):
		x=[]+[n[0]]
		for i in range(len(n)):
			if n[i] == ' ':
				x.append(n[i+1])
		for i in x:
			print (i, end = "")
		print("")
		return x
	n=str(input("Nombre:"))
	sigla(n)
	
	


###########ejer36.py###########

def ejer36():
	def sumalista(XS):
		b=0
		for i in range(len(XS)):
			b+=int(XS[i])	
		return b
	XS=str(input("Numero:"))
	print("La suma es:",sumalista(XS))


###########ejer37.py###########

def ejer37():
	def fecha(d,m,y):
		xs = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
		print (d,'de',xs[m-1],y)
	fecha = str(input("Fecha (dia/mes/año):"))
	if fecha[0] == str(0):
		d=fecha[1]
	else:
		d=fecha[0:2]
	
	if fecha[3]==str(0):
		m=fecha[4]
	else:
		m=fecha[3:5]
	y=fecha[6:]
	
	fecha(int(d),int(m),int(y))


###########ejer38.py###########

def ejer38():
	archivo_texto = open("texto","r")
	lineas = archivo_texto.readlines()
	archivo_texto.close
	def contar(xs):
		contMayusc = 0
		contMinus = 0
		contDigitos = 0
		contBlanks = 0
		for i in xs:
			if 65 <= ord(i) <= 90:
				contMayusc += 1
			if 97 <= ord(i) <= 122:
				contMinus += 1
			if i == ' ':
				contBlanks += 1
			contDigitos += 1
		return [contMayusc,contMinus,contDigitos,contBlanks]
	
	info_Lineas = []
	for i in lineas:
		info_Lineas.append(contar(i))
	# print(info_Lineas) solo de verificacion
	
	def suma_ListadeLista(xs): # Esta función suma los elementos de una lista de listas
							   # Suponiendo que todos son iguales
		total = [0,0,0,0]
		for j in range(4):
			for i in range(len(xs)):
				total[j] += xs[i][j]
	
		return total
	
	# print(suma_ListadeLista(info_Lineas)) sólo de verificación
	
	def mostrarMensaje(xs):
		print("Se han contado",xs[0],"Letras Mayusculas")
		print("Se han contado",xs[1],"Letras Minusculas")
		print("Se han contado",xs[2],"Dígitos")
		print("Se han contado",xs[3],"Espacios en blanco")
	
	print("Del archivo",archivo_texto)
	mostrarMensaje(suma_ListadeLista(info_Lineas))
	


###########ejer39.py###########

def ejer39():
	def separadorPalabras(xs):
		palabras = []
		cont1 = 0
		cont2 = 0
		for i in xs:
			if i == ' ':
				palabras.append(xs[cont2:cont1])
				cont2 = cont1 + 1
			cont1 += 1
		palabras.append(xs[cont2:])
		print(palabras)
		return palabras
	
	def c(xs,posc):
		a = xs[posc]
		cont = 0
		for i in xs:
			if a == i:
				cont += 1
		return [cont,a]
	
	def buscar(xs,elemento): # busca un elemento en la lista
		for i in xs:
			if i == elemento:
				return True
		return False
	
	texto = str(input("Ingrese el texto a analizar: "))
	
	list1 = separadorPalabras(texto)
	list2 = []
	
	for i in range(len(list1)):
		if not buscar(list2,c(list1,i)):
			list2.append(c(list1,i))
	print(list2)
	
	# buscar el mayor de la lista2
	mayorlista = list2[0]
	mayor = list2[0][0]
	for i in range(len(list2)):
		if mayor < list2[i][0]:
			mayor = list2[i][0]
			mayorlista = list2[i]
	
	print("La palabra que mas repite es", mayorlista[1], "con", mayorlista[0], "repeticiones")
	


###########ejer40.py###########

def ejer40():
	def separador(xs):
		p=[]
		cont1 = 0
		cont2 = 0
		for i in xs:
			if i == ' ':
				p.append(xs[cont2:cont1])
				cont2 = cont1 + 1
			cont1 += 1
		p.append(xs[cont2:])
		print(p)
		return p
	
	def latin_Pig(xs):
		aux1 = xs[0]
		xs = xs[1:]
		aux2 = 'AY'
		xs += aux1 + aux2
		return xs
	
	t= str(input("Ingrese el texto:"))
	listaPalabras = separador(t)
	latinPig = []
	for i in listaPalabras:
		latinPig.append(latin_Pig(i))
	print(latinPig)
	
	for i in latinPig:
		print(i, end = " ")
	print(" ")



###########unidordeArchivos.py###########

def unidordeArchivos():
	import os
	ficheros = os.listdir(".")
	ficheros.sort()
	nuevoContenido = ""
	for fichero in ficheros:
		if fichero.split(".")[1] == "py":
			archivo = open(fichero, "r+")
			nuevoContenido+="###########"+fichero+"###########\n\n"
			nuevoContenido+="def " + fichero.split(".")[0] + "():\n"
			for linea in archivo.readlines():
				nuevoContenido+="\t"+linea
			nuevoContenido+="\n\n"
			archivo.close()
	archivo = open("archivosUnidos.py", "w")
	archivo.write(nuevoContenido)
	archivo.close()



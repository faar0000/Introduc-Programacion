import os
ficheros = os.listdir(".")
ficheros.sort()
nuevoContenido = ""
for fichero in ficheros:
	if fichero.split(".")[1] == "py":
		archivo = open(fichero, "r+")
		nuevoContenido+="###########"+fichero+"###########\n\n"
		nuevoContenido+="def " + fichero.split(".")[0] + "():\n"
		for linea in archivo.readlines():
			nuevoContenido+="\t"+linea
		nuevoContenido+="\n\n"
		archivo.close()
archivo = open("archivosUnidos.py", "w")
archivo.write(nuevoContenido)
archivo.close()

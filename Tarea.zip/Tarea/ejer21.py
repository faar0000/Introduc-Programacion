def failling_distrance(time):
    g=9.8
    d=g*time**2/ 2
    return d
print("Tiempo(s)\tDistancia(m)")
 
for i in range(1,11):
    print(str(i) + " s\t\t" + str((failling_distrance(i))))

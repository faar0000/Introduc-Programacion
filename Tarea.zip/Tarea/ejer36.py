def sumalista(XS):
	b=0
	for i in range(len(XS)):
		b+=int(XS[i])	
	return b
XS=str(input("Numero:"))
print("La suma es:",sumalista(XS))

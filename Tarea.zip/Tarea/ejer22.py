import random
 
def par(xs):
    par= 0
    impar= 0
    for i in xs:
        if i % 2 == 0:
            par+= 1
        else:
            impar+= 1
    print("Se han contado",par, "números pares y",impar, "números impares")
 
xs = []
for i in range(100):
    xs.append(random.randint(1,10))
 
print(xs)
 
par(xs)
